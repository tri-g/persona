import { Component, OnInit } from '@angular/core';
import * as Highcharts from 'highcharts';
import more from 'highcharts/highcharts-more';
more(Highcharts);
import HighchartsNetworkgraph from 'highcharts/modules/networkgraph'; 
HighchartsNetworkgraph(Highcharts);

@Component({
  selector: 'app-network-graph',
  templateUrl: './network-graph.component.html',
  styleUrls: ['./network-graph.component.css']
})
export class NetworkGraphComponent implements OnInit {
  constructor() {}

  ngOnInit(): void {}


highchartss = Highcharts;
   chartOptionss = {   
     chart: {
     name:'gtyhu',
    type: 'networkgraph',
    plotBorderWidth: 1,
     height: '50%',
     size: '50%',
  },

  legend: {
    enabled: false
  },
  plotOptions: {
    series: {
      
       networkgraph: {
      layoutAlgorithm: {
      enableSimulation: true
      }
    }
    }
  },
 series: [{
    marker: {
      radius: 20
    },
    dataLabels: {
      enabled: true,
      linkFormat: '',
      allowOverlap: false
    },
     nodes: [{
      id: 'Node 1',
       marker: {
              radius: 70
            },
      
    },


     {
      id: 'ATM',
      color: 'red'
    }, {
      id: 'Auto Insurance',
      color: 'orange'
    },
    {
      id: 'Auto Loan',
      color: 'green'
    },
    {
      id: 'Automotive',
      color: 'blue'
    },
    {
      id: 'Balance Transfers',
      color: 'pink'
    },
    {
      id: 'Auto Insurance',
      color: 'purple'
    },
    {
      id: 'Department Stores',
      color: 'yellow'
    },
 {
      id: 'Entertainment',
      color: 'grey'
    },

 {
      id: 'Gasoline',
      color: 'DarkOliveGreen'
    },


 {
      id: 'Health Insurance',
      color: 'DarkSeaGreen'
    },


 {
      id: 'Home Improvement',
      color: 'DarkSlateGray'
    },

 {
      id: 'Medical Services',
      color: 'IndianRed'
    },
 {
      id: 'Merchandise',
      color: 'Lime'
    },
 {
      id: 'Mortgage',
      color: 'Navy'
    },
 {
      id: 'Rent',
      color: '#98FB98'
    },
 {
      id: 'Restuarants',
      color: 'PaleVioletRed'
    },
 {
      id: 'Services',
      color: 'PowderBlue'
    },
 {
      id: 'Supermarkets',
      color: 'SandyBrown'
    },

 {
      id: 'Technology',
      color: 'Teal'
    },

 {
      id: 'Services',
      color: 'Turquoise'
    },
{
      id: 'Travel',
      color: 'Thistle'
    },
    ],
    data: [
      {from:'Node 1', to:'ATM',name:'gtyhu'},
      {from:'Node 1', to:'Auto Insurance'},
      {from:'Node 1', to:'Auto Loan'},
       {from:'Node 1', to:'Automotive'},
        {from:'Node 1', to:'Balance Transfers'},
         {from:'Node 1', to:'Department Stores'},
         {from:'Node 1', to:'Entertainment'},
        {from:'Node 1', to:'Gasoline'},
         {from:'Node 1', to:'Health Insurance'},
         {from:'Node 1',to:'Home Improvement'},
         {from:'Node 1',to:'Medical Services'},
         {from:'Node 1', to:'Merchandise'},
         {from:'Node 1', to:'Mortgage'},
         {from:'Node 1',to: 'Rent'},
        {from:'Node 1', to:'Restuarants'},      
         {from:'Node 1', to:'Services'},
         {from:'Node 1', to:'Supermarkets'},
          {from:'Node 1',to: 'Technology'},
          {from:'Node 1',to: 'Travel'},



    ]
  }]
  }
}