export class Demographics{
client_id: string; 
}