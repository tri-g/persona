import { Component, OnInit } from '@angular/core';
import { ActivatedRoute,Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { PersonaService } from '../persona.service';
import { Observable } from 'rxjs';
import {Locations} from "./../locations";

@Component({
  selector: 'app-gmaps',
  templateUrl: './gmaps.component.html',
  styleUrls: ['./gmaps.component.css']
})
export class GmapsComponent implements OnInit {
 zoom: number = 8; 
 TRANS_LATITUDE: number = 39.817490;
 TRANS_LONGITUDE: number = -0.231035;
 options1=[];
   

  constructor(private router: Router, private route: ActivatedRoute,private http: HttpClient, private pservice:PersonaService) { }

  ngOnInit(): void {
 
  this.pservice.mapcategorycreditcard().subscribe((data:any) => {
      this.options1 = data;
      console.log(this.options1);
    });
      
  
  }


    
     
    
}
