export class Locations{
TRANS_LATITUDE: number; 
TRANS_LONGITUDE: number; 
}